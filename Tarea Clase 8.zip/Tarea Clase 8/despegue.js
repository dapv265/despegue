function despegue(conteo){

    for (let i = conteo; i >= 0; i--) {
    console.log(i);
    
    }
    console.log("¡Despegue!")
}

despegue(25);